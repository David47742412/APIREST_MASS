const {Router} = require('express');
const router = Router();

router.get('/user', (req, res)=>{
});

module.exports = router;